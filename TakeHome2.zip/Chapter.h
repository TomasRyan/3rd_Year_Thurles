#ifndef CHAPTER_H
#define CHAPTER_H

#include <string>
#include <algorithm> 
#include <list> 
#include "Enums.h"
#include <iostream>
#include "InputHandler.H"
#include "Battle.h"
#include "Party.h"
#include "Battle.h"
using namespace std;
//--------------------------------------------
//	Tom�s Ryan
//	k00243524
// 	take home assignment 2 games programming
//--------------------------------------------
// chapter object, contains all the text and references to each other chapter that the chapter is connected to
//--------------------------------------------

class Chapter {
private:
	int chapterID; // id of the chapter
	string text; // the main text of the chapter
	list<string> responses; // length of enum Verbs, with the resonse correlating with the index of enum verbs
	list<int> nextChapters; // the index of the chapters that can be accessed from here, correlating to the enum position
	InputHandler input = InputHandler();
	list<string> availableresponses; // the list of paths avalibale to the player
	EnemyEncounter listOfEnemys = EnemyEncounter();	// list of enemys if the chapter contains a fight scene
	Battle chapterFight = Battle(); // battle required for the fight scenes, empty at first
	bool fight = false;
public:
	//	reguler chapter constructer, with input and responses
	Chapter(int ID, string t, list<string> re, list<int> next, list<string> aRe);
	//	battle chapter constrcuter, takes in a list of enemy references for EnemyEncounter to construct with
	Chapter(int ID, string t,  list<int> e, int next);
	//prints string text
	void printText(Party p);
	// prints out the string at the index of responses and returns the next scene
	int printResponse(Party p, string i);
	// returns if the fight is won or not
	bool victorCheck();
	bool fightChecker();
	void fightScene(Party p);
};
#endif // CHAPTER_H