#include "Creator.h"
//--------------------------------------------
//	Tom�s Ryan
//	k00243524
// 	take home assignment 2 games programming
//--------------------------------------------
//
//--------------------------------------------
/*************************************************
example layout
//--------------------------------------------------
//chapter a1 // chapter 0
int a1chapterID = 0;
string a1mainText = "this is a test";
list<string> a1Responses;
a1Responses.push_back("I dont understand what you want to do");
a1Responses.push_back(" ");
a1Responses.push_back(" ");
list<int> a1ConnectedChapters = { 0,0,0 }; // default this back to the scene id
list<string> possablePaths;
a1PossablePaths.push_back("1)	");
a1PossablePaths.push_back("2)	");
a1PossablePaths.push_back("3)	");
Chapter a1Chapter(a1chapterID,a1mainText, a1Responses, a1ConnectedChapters, list<string> possablePaths);
listOfChapters.push_back(a1Chapter);
//--------------------------------------------------
************************************************/

list<Chapter> Creator::create() {
	list<Chapter> listOfChapters;
	// chapter a1 // chapter 0
	int a1chapterID = 0;
	string a1mainText = "After travelling through the morning you find yourself approching the town of Huckleduke, a small mining town that has recently gained infamy for a majour orc problem that has been recently plaguing the town. Being an adventurer of no small renown you and your party have been personally requested to show up by a local lord called Rolen Hanali. you are to meet him at the BirdCage Inn.";
	list<string> a1Responses;
	a1Responses.push_back("I dont understand");
	a1Responses.push_back("You make your way to the inn");
	a1Responses.push_back("Looking around you see a plain, simple town, not filled with many luxurys, only basics goods stores and housing");
	a1Responses.push_back("You cant find anybody who is willing to talk to strangers, only recieveing grunts from those who you tried to talk to");
	list<int> a1ConnectedChapters = { 0,1,0,0 }; // default this back to the scene id
	list<string> a1PossablePaths;
	a1PossablePaths.push_back("1: Go to the inn");
	a1PossablePaths.push_back("2: look around");
	a1PossablePaths.push_back("3: Talk to the locals");
	Chapter a1Chapter(a1chapterID,a1mainText, a1Responses, a1ConnectedChapters, a1PossablePaths);
	listOfChapters.push_back(a1Chapter);
	//--------------------------------------------------
	//chapter a2 // chapter 1
	int a2chapterID = 1;
	string a2mainText = "After being pointed the right way by the locals you quickly arrive at the BirdCage inn. It looks like a very modest establishment, but even at these early hours the place is filled to the brim with patrons";
	list<string> a2Responses;
	a2Responses.push_back("I dont know what ya mean");
	a2Responses.push_back("Looking about you realise that you dont quite know how to find him, you approch the bar and ask the patrons about him. 'Ah are ye them adventurers mistor Hanali had hired? sit yourselves down and I will send somebody to fetch him for ya' with that you are given a round of drinks and a short while later the barkeeper beckens your party to follow him into a back rooom.");
	a2Responses.push_back("You ask the patrons about Rolen Hanali, a dwarfen man with a long ginger beard knows about your quary. 'Ah are ye them adventurers mistor Hanali had hired? sit yourselves down and I will send somebody to fetch him for ya' with this you see him signal the barkeep as he nods and head into a backroom, returning after a few secounds and bekons your party to follow him ");
	list<int> a2ConnectedChapters = { 1,2,2 }; // default this back to the scene id
	list<string> a2PossablePaths;
	a2PossablePaths.push_back("Look for Rolen Hanali");
	a2PossablePaths.push_back("Talk to the patrons to see if they know where he is");
	Chapter a2Chapter(a2chapterID, a2mainText, a2Responses, a2ConnectedChapters, a2PossablePaths);
	listOfChapters.push_back(a2Chapter);
	//--------------------------------------------------
	//chapter a3 // chapter 2
	int a3chapterID = 2;
	string a3mainText = "As you are led into the backroom you meet a tall, well dressed elfen man. 'Hello there! I trust your journey was no trouble?' he motions to the barkeep and for all of ye to sit down, and as ye do so another round of drinks are brought about. 'Right then, lets get down to business shall we? Ive asked ye to come here as my son has gone missing, and with the recent attacks on the town I'm very worried about his safekeeping. Id like for your group to find him and return him to me before the end of the week do we have a understanding?";
	list<string> a3Responses;
	a3Responses.push_back("he stares back at you");
	a3Responses.push_back("'Good! well then I have other matters to attend to so Il leave you too it!' and with that he hastely leaves the room, you all return to the main barroom and begin your search");
	a3Responses.push_back("Oh of course! I believe that some of the townsfolk saw him leave the town, so id start there. Also you all know that I am willing to pay top coin for your services!");
	list<int> a3ConnectedChapters = { 2,3,2 }; // default this back to the scene id
	list<string> a3PossablePaths;
	a3PossablePaths.push_back("Say that you will do it");
	a3PossablePaths.push_back("Look for more details");
	Chapter a3Chapter(a3chapterID, a3mainText, a3Responses, a3ConnectedChapters, a3PossablePaths);
	listOfChapters.push_back(a3Chapter);
	//--------------------------------------------------
	//chapter a4 // chapter 3
	int a4chapterID = 3;
	string a4mainText = "Within the bar room you begin your seach";
	list<string> a4Responses;

	a4Responses.push_back("I dont understand");
	a4Responses.push_back("You head out into the town, asking about for your quarry, with some searching you do find out that he left with a local woman out the south side of town a couple of days ago");
	a4Responses.push_back("You order a few more drinks, and as ye enjoy them the barkeep asks you for a favor");
	list<int> a4ConnectedChapters = { 3,5,4 }; // default this back to the scene id
	list<string> a4PossablePaths;
	a4PossablePaths.push_back("1)	Ask about the town.");
	a4PossablePaths.push_back("2)	Relax in the inn before you head off.");
	Chapter a4Chapter(a4chapterID, a4mainText, a4Responses, a4ConnectedChapters, a4PossablePaths);
	listOfChapters.push_back(a4Chapter);
	//--------------------------------------------------
	//chapter a5 // chapter 4
	int a5chapterID = 4;
	string a5mainText = "The Barkeep says to you: 'I see that I have a... small rodent problem in the basement right now and I would pay you 10 gold pieces and free drinks for a week if you can handle it for me... descretly of course";
	list<string> a5Responses;
	a5Responses.push_back("temp1");	// error

	a5Responses.push_back("he stares blankly back at you");
	a5Responses.push_back("You agree, and ready yourselves as you arrive at the basement");
	a5Responses.push_back("You reply that you have other jobs to do, and then leave the inn and begin your search");

	list<int> a5ConnectedChapters = { 4,6,5 }; // default this back to the scene id
	list<string> a5PossablePaths;
	a5PossablePaths.push_back("1)	agree, and head down to deal with the problem immediatly");
	a5PossablePaths.push_back("2)	reply that you are on another job atm, and procede to begin your search.");
	Chapter a5Chapter(a5chapterID, a5mainText, a5Responses, a5ConnectedChapters, a5PossablePaths);
	listOfChapters.push_back(a5Chapter);
	//--------------------------------------------------
	//chapter a6 // chapter 5
	int a6chapterID = 5;
	string a6mainText = "As you follow the trail you are attacked by a group of Goblins!";
	list<int> a6BattleList = { 7,7,7,7,7 }; // default this back to the scene id
	Chapter a6Chapter(a6chapterID, a6mainText, a6BattleList, 8);
	listOfChapters.push_back(a6Chapter);
	//--------------------------------------------------
	//--------------------------------------------------
	//chapter a7 // chapter 6
	int a7chapterID = 6;
	string a7mainText = "As you step down into the celler, the only thing that overpowers the smell of stale ale is the strong stench of something rotting. as your party search's about the dimly lit room you are suddenly attacked by a swarm of large rats!";
	list<int> a7BattleList = { 10, 10, 10 }; // default this back to the scene id
	Chapter a7Chapter(a7chapterID, a7mainText, a7BattleList, 7);
	listOfChapters.push_back(a7Chapter);
	//--------------------------------------------------
	//chapter a8 // chapter 7
	int a8chapterID = 7;
	string a8mainText = "after removing the very dangorous rodents from teh celler, you tell the barkeep of your deeds. well done!, very well done! also while you were busy, I think I found out where you may begin your search.' he hands you a map, and after a round on the house your party leaves to begin there search out the south side of town.";
	list<string> a8Responses;
	list<int> a8ConnectedChapters = { 5 }; // default this back to the scene id
	list<string> a8PossablePaths;
	Chapter a8Chapter(a8chapterID, a8mainText, a8Responses, a8ConnectedChapters, a8PossablePaths);
	listOfChapters.push_back(a8Chapter);
	//--------------------------------------------------
	// chapter a9 // chapter 8
	int a9chapterID = 8;
	string a9mainText = "After surviving the ambush y0u inspect the surroundings and discover 2 sets of tracks, which set will you follow?";
	list<string> a9Responses;
	a9Responses.push_back("I dont understand");
	a9Responses.push_back("you follow the tracks");
	a9Responses.push_back("you follow the tracks");
	a9Responses.push_back("The set going to the west are from a hourse and carrage, while the set going to the south are of many, smaller tracks, very similer to said goblins you faced");
	int rng = r.getRandom(0, 30);
	list<int> a9ConnectedChapters;
	if (rng < 15) {
		a9ConnectedChapters = { 8, 9, 1, 8 }; // default this back to the scene id
	}
	else {
		a9ConnectedChapters = { 8, 11, 9, 8 }; // default this back to the scene id
	}
	list<string> a9PossablePaths;
	a9PossablePaths.push_back("1: follow the western tacks");
	a9PossablePaths.push_back("2: follow the southern tracks");
	a9PossablePaths.push_back("3: Inspect the tracks in more detail");
	Chapter a9Chapter(a9chapterID, a9mainText, a9Responses, a9ConnectedChapters, a9PossablePaths);
	listOfChapters.push_back(a9Chapter);
	//--------------------------------------------------
	//chapter a10 // chapter 9
	int a10chapterID = 9;
	string a10mainText = "You arrive at the destination of the tracks, and find a ruined camp";
	list<string> a10Responses;

	a10Responses.push_back("and there was nothing you can do");
	a10Responses.push_back("you explore the camp, and quickly discovered the remains of what seems to be a desperate struggle");
	a10Responses.push_back("you head back");

	list<int> a10ConnectedChapters = { 9,10,8 }; // default this back to the scene id
	list<string> a10PossablePaths;
	a10PossablePaths.push_back("1)	investigate the camp");
	a10PossablePaths.push_back("2)	backtrack.");
	Chapter a10Chapter(a10chapterID, a10mainText, a10Responses, a10ConnectedChapters, a10PossablePaths);
	listOfChapters.push_back(a10Chapter);
	//--------------------------------------------------
	//chapter a11 // chapter 10
	int a11chapterID = 10;
	string a11mainText = "Upon exploring the camp you discover a locket with your quarrys image attached to it, aswell as the set of tracks seeming to leave teh camp in another direction";
	list<string> a11Responses;
	a11Responses.push_back("...");	// error

	a11Responses.push_back("You follow these tracks until you come upon a mouth of a cave");

	list<int> a11ConnectedChapters = { 10,13 }; // default this back to the scene id
	list<string> a11PossablePaths;
	a11PossablePaths.push_back("1)	Follow these tracks");
	Chapter a11Chapter(a11chapterID, a11mainText, a11Responses, a11ConnectedChapters, a11PossablePaths);
	listOfChapters.push_back(a11Chapter);
	//--------------------------------------------------
	//chapter a12 // chapter 11
	int a12chapterID = 11;
	string a12mainText = "You follow these tracks until you discover an ogre in the process of ripping a full carrage apart by hand! as you approch to see the damage it spots you and charges you!";
	list<int> a12BattleList = { 8 }; // default this back to the scene id
	Chapter a12Chapter(a12chapterID, a12mainText, a12BattleList, 12);
	listOfChapters.push_back(a12Chapter);
	//--------------------------------------------------
	//chapter a13 // chapter 12
	int a13chapterID = 12;
	string a13mainText = "as teh ogre falls a small halfing man reveals himself from his nearby hiding spot, he seems every shaken";
	list<string> a13Responses;

	a13Responses.push_back("he stares blankly back at you");
	a13Responses.push_back("he nervously tells you that he was ambushed as he passedby a nearby cave, also mentioning that he thought he saw someone being dragged into said cave. you begin your search for this cave");
	a13Responses.push_back("he says that he think he saw someone being fdragged off in the direction of a nearby cave, giving you directions. you begin your search for this cave");

	list<int> a13ConnectedChapters = { 4,13,13 }; // default this back to the scene id
	list<string> a13PossablePaths;
	a13PossablePaths.push_back("1)	ask what happened");
	a13PossablePaths.push_back("2)	ask him if hes seen the man that you are looking for");
	Chapter a13Chapter(a13chapterID, a13mainText, a13Responses, a13ConnectedChapters, a13PossablePaths);
	listOfChapters.push_back(a13Chapter);
	//--------------------------------------------------
	//chapter a14 // chapter 13
	int a14chapterID = 13;
	string a14mainText = "you arrive to the mouth of the cave, wich is being dimly lit inside";
	list<string> a14Responses;

	a14Responses.push_back("...");
	a14Responses.push_back("your group steels themselves and heads inside");
	a14Responses.push_back("your group loses there cool, and feels in terror");

	list<int> a14ConnectedChapters = { 4,14,15, }; // default this back to the scene id
	list<string> a14PossablePaths;
	a14PossablePaths.push_back("1)	head inside");
	a14PossablePaths.push_back("2)	flee in terror");
	Chapter a14Chapter(a14chapterID, a14mainText, a14Responses, a14ConnectedChapters, a14PossablePaths);
	listOfChapters.push_back(a14Chapter);
	//--------------------------------------------------
	//chapter a15 // chapter 14
	int a15chapterID = 14;
	string a15mainText = "you head inside, and as you do notice you see the man you are looking for! being dumped into a cooking pot by the biggest ogre you have ever seen, triple the size of any you have seen before. as you gaze upon it, it sniffs and turns to face you, picking up its large club with a big roar, pointing it towards you as a few gobilns who were tending to teh cooking rise and attack you!";
	list<int> a15BattleList = { 7, 9, 7 }; // default this back to the scene id
	Chapter a15Chapter(a15chapterID, a15mainText, a15BattleList, 16);
	listOfChapters.push_back(a15Chapter);
	//--------------------------------------------------
	//chapter a16 // chapter 15
	int a16chapterID = 15;
	string a16mainText = "as your group runs in shear terror from teh menancing cave, tales of your groups cowardice begin to spread throughout the lands";
	list<string> a16Responses;
	a16Responses.push_back("yup, game over");

	list<int> a16ConnectedChapters = { 99 }; // default this back to the scene id
	list<string> a16PossablePaths;
	a16PossablePaths.push_back("1)	oh...");
	Chapter a16Chapter(a16chapterID, a16mainText, a16Responses, a16ConnectedChapters, a16PossablePaths);
	listOfChapters.push_back(a16Chapter);
	//--------------------------------------------------
	//chapter a17 // chapter 16
	int a17chapterID = 16;
	string a17mainText = "as the last of your foes fall, you fish out the lords sun from the pot, saving him from being burnt alive. and with this success you head back to teh town heroes!";
	list<string> a17Responses;


	list<int> a17ConnectedChapters = { 16 }; // default this back to the scene id
	list<string> a17PossablePaths;
	Chapter a17Chapter(a17chapterID, a17mainText, a17Responses, a17ConnectedChapters, a17PossablePaths);
	listOfChapters.push_back(a17Chapter);
	//--------------------------------------------------
	// THE END
	//
	//###################################################
	// game over chapter
	int gameOver = 99;
	string gameOverText = "Game Over";
	list<string> gameOverResponses;
	list<int> gameOverConnectedChapters = { 0,0,0,0,0,0,0,0,0,0 }; // default this back to the scene id
	list<string> gameOverPossablePaths;
	gameOverPossablePaths.push_back("Idunno");
	Chapter gameOverChapter(gameOver, gameOverText, gameOverResponses, gameOverConnectedChapters, gameOverPossablePaths);
	listOfChapters.push_back(gameOverChapter);
	return listOfChapters;
}