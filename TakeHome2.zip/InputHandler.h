#ifndef INPUTHANDLER_H
#define INPUTHANDLER_H
#include <string>
#include <algorithm> 
#include <list> 
#include "Enums.h"
#include <sstream>
using namespace std;
class InputHandler {
public:
	InputHandler();
	int numberChecker(string num);
	//return a single int of all verbs used in enum verbs
	int verbChecker(string s);
};
#endif // INPUTHANDLER_H