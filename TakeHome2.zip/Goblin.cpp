#include "Goblin.h";
Goblin::Goblin(int health) {
	this->m_typeID = goblin;
	this->m_maxHealth = health;
	this->m_currHealth = health;
}

Goblin::Goblin() {
	this->m_name = "Goblin";
	this->m_typeID = goblin;
	this->m_maxHealth = 15;
	this->m_currHealth = 15;
	this->m_attack = 5;
	this->m_defense = 2;
	this->m_luck = 2;
	this->m_speed = 3;
}


