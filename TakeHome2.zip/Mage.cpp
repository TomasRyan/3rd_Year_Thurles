#include "Mage.h";
Mage::Mage(int x, int y) {
	this->m_xPos = x;
	this->m_yPos = y;
	this->m_typeID = mage;
}
Mage::Mage(string name, int h, int s, int a, int d, int l) {
	this->m_name = name;
	this->m_maxHealth = h;
	this->m_currHealth = h;
	this->m_speed = s;
	this->m_attack = a;
	this->m_defense = d;
	this->m_luck = l;
	this->m_typeID = mage;
}

void Mage::attack(GameCharacter* target) {
	int random = r.getRandom(1, this->m_attack);
	int totalDamage = random;
	while (random == this->m_attack) {
		cout << "|||||||||||||||||||||||||" << endl;
		cout << "|||||||||OVERLOAD||||||||" << endl;
		cout << "|||||||||||||||||||||||||" << endl;
		random = r.getRandom(0, this->m_attack);
		totalDamage += random;
	}
	random = r.getRandom(0, 100);
	if (random < this->m_luck) {
		totalDamage *= 2;
	}
	if (totalDamage > 0) {
		cout << "#####################################" << endl;
		cout << this->m_name << " attacks " << target->getName() << " for " << totalDamage << " damage!" << endl;
		cout << "#####################################" << endl;
		target->takeDamage(totalDamage);
	}
	else {
		cout << this->m_name << " missed there attack!" << endl;
	}
}

void Mage::Special() {
	this->isSpecialReady = true;
}

void Mage::stats() const {
	cout << this->m_name << " the Mage" << endl;
	cout << "----------------------------------" << endl;
	cout << "Health: " << this->m_currHealth << "/" << this->m_maxHealth << endl;
	cout << "Attack: " << this->m_attack << endl;
	cout << "Defense: " << this->m_defense << endl;
	cout << "Speed: " << this->m_speed << endl;
	cout << "Luck: " << this->m_luck << endl;
}

string Mage::getName()
{
	string temp = this->m_name + " the Mage";
	return  temp;
}

