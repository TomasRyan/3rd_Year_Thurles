#include <iostream>
#include "GameCharacter.h";
#include "Player.h";
#include "Enemy.h";
#include <list>;
using namespace std;