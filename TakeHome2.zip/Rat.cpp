#include "Rat.h";
Rat::Rat(int health) {
	this->m_typeID = rat;
	this->m_maxHealth = health;
	this->m_currHealth = health;
}

Rat::Rat() {
	this->m_name = "Rat";
	this->m_typeID = rat;
	this->m_maxHealth = 10;
	this->m_currHealth = 10;
	this->m_attack = 3;
	this->m_defense = 2;
	this->m_luck = 1;
	this->m_speed = 3;
}

