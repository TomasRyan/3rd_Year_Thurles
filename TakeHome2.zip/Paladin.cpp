#include "Paladin.h";
Paladin::Paladin(int x, int y) {
	this->m_xPos = x;
	this->m_yPos = y;
	this->m_typeID = cleric;
}
Paladin::Paladin(string name, int h, int s, int a, int d, int l) {
	this->m_name = name;
	this->m_maxHealth = h;
	this->m_currHealth = h;
	this->m_speed = s;
	this->m_attack = a;
	this->m_defense = d;
	this->m_luck = l;
	this->m_typeID = paladin;
}

//void Paladin::attack(GameCharacter* target) {
//	target->takeDamage(this->m_attack);
//}

void Paladin::Special(list<GameCharacter*> party) {
	cout << this->getName() << " grants armour to the party" << endl;
	for (GameCharacter* c : party) {
		c->healingUnit(this->ArmourAddition);
	}
}

void Paladin::stats() const {
	cout << this->m_name << " the Paladin" << endl;
	cout << "----------------------------------" << endl;
	cout << "Level: " << this->m_level << endl;
	cout << "Health: " << this->m_currHealth << "/" << this->m_maxHealth << endl;
	cout << "Attack: " << this->m_attack << endl;
	cout << "Defense: " << this->m_defense << endl;
	cout << "Speed: " << this->m_speed << endl;
	cout << "Luck: " << this->m_luck << endl;
}


string Paladin::getName()
{
	string temp = this->m_name + " the Paladin";
	return  temp;
}

