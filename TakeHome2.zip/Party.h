#pragma once
#include <list>
#include "GameCharacter.h";
#include "Fighter.h"
#include "Thief.h"
#include "Cleric.h"
#include "GunSlinger.h"
#include "Paladin.h"
#include "Mage.h"
#include "Item.h"
//--------------------------------------------
//	Tom�s Ryan
//	k00243524
// 	take home assignment 2 games programming
//--------------------------------------------
// ogre enemy type, based off of GameCharecter
//--------------------------------------------
class Party {
private:
	list<GameCharacter*> partyList;
	list<Item> inventory; // needs to be updated
	Random generater = Random();
public:
	Party();
	void AddPartyMembers();
	void LevelParty();
	list<GameCharacter*> getPartyList();
	void drawHud();
	bool isPartyAlive();
	void createFighter();
	void createThief();
	void createCleric();
	void createGunSlinger();
	void createPaladin();
	void createMage();
	void addItem(Item i);
};