#pragma once
#include "GameCharacter.h";
//--------------------------------------------
//	Tom�s Ryan
//	k00243524
// 	take home assignment 2 games programming
//--------------------------------------------
// thief player type, based off of GameCharecter
//--------------------------------------------
class Thief : public GameCharacter {
private:
	bool canCrit = false;
public:
	Thief(string name, int h, int s, int a, int d, int l);
	Thief(int x, int y);
	void attack(GameCharacter* target);
	virtual void Special();
	bool critCheck(GameCharacter* target);
	virtual void stats() const;
	string getName();
	// virtual, so no definition within GameCharacter, check player and enemy for definition
};