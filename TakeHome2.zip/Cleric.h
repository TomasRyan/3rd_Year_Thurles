#pragma once
#pragma once
#include "GameCharacter.h";
//--------------------------------------------
//	Tom�s Ryan
//	k00243524
// 	take home assignment 2 games programming
//--------------------------------------------
// cleric player type, based off of GameCharecter
//--------------------------------------------
class Cleric : public GameCharacter {
private:
	int healAmount = 10;
public:
	Cleric(string name, int h, int s, int a, int d, int l);
	Cleric(int x, int y);
	//void attack(GameCharacter* target);
	// for healing allies
	virtual void Special(list<GameCharacter*> battleGrid);
	virtual void stats() const;
	string getName();
	// virtual, so no definition within GameCharacter, check player and enemy for definition
};