#pragma once
#include "GameCharacter.h";
//--------------------------------------------
//	Tom�s Ryan
//	k00243524
// 	take home assignment 2 games programming
//--------------------------------------------
// ogre enemy type, based off of GameCharecter
//--------------------------------------------
class Ogre : public GameCharacter {
private:

public:
	Ogre();
	Ogre(int health);
};