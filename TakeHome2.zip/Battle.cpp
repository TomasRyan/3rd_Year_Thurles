
#include "Battle.h";

Battle::Battle()
{
}

Battle::Battle(Party p, EnemyEncounter e) {
	vpGameCharacters = p.getPartyList();
	vpEnemys = e.getEnemyList();
}



void Battle::battleLoop() {
	while (overCheck() == true) {
		//////////////////////////////////////////////////////////////
		string input;
		transform(input.begin(), input.end(), input.begin(), ::tolower);
		for (GameCharacter* g : vpGameCharacters) {
			if (g->isAlive()) {
				removeDead();
				if (g->getRole() == fighter || g->getRole() == thief ||
					g->getRole() == mage || g->getRole() == gunslinger ||
					g->getRole() == paladin || g->getRole() == cleric && g->isAlive()) {
					g->stats();
					cout << "#####################################" << endl;
					cout << "## " << g->getName() << endl;
					cout << "##-----------------" << endl;
					cout << "## 1: Attack" << endl;
					//cout << "## 2: Defend" << endl;
					cout << "## 2: Special" << endl;
					cout << "## 3: Item" << endl;
					cout << "#####################################" << endl;
					cout << "## What would you like to do, " << g->getName() << "??" << endl;
					cout << "## ";
					cin >> input;
					cin.clear();

					if (input == "1" || input == "attack") {
						if (g->getRole() == gunslinger || g->getRole() == mage && g->specialready()) {
							g->attack(vpEnemys);
							removeDead();
						}
						else {
							int temp = vpEnemys.size();
							temp = r.getRandom(0, temp);
							int counter = 0;
							list<GameCharacter*>::iterator it = vpEnemys.begin();
							while (counter < temp && it != vpEnemys.end()) {
								it++;
								counter++;
							}
							g->attack((*it));
							removeDead();
							if (overCheck() == false) {
								break;
							}
						}
					}
					else if (input == "2" || input == "special") {
						if (g->getRole() == paladin || g->getRole() == cleric) {
							g->Special(vpGameCharacters);
						}
						else {
							g->Special();
						}
					}
					else if (input == "3" || input == "item") {
						g->itemUse();
					}
				}
			}
		}
		for (GameCharacter* e : vpEnemys) {
			e->stateCheck();
			int temp = vpGameCharacters.size();
			temp = r.getRandom(0, temp - 1);
			int counter = 0;
			list<GameCharacter*>::iterator it = vpGameCharacters.begin();
			while (counter < temp && it != vpGameCharacters.end()) {
				it++;
				counter++;
			}
			e->attack((*it));
		}
		printBattle();
	}
}

void Battle::printBattle() {

}

void Battle::updateBattleBoard() {

}

bool Battle::runAway()
{
	if (r.getRandom(0, 2) == 0) {
		list<GameCharacter*>::iterator it = vpEnemys.begin(); // iterater pointed at the start of list of GameCharecters
		while (it != vpEnemys.end()) {
			delete* it;
			it = vpEnemys.erase(it); // deletes element that it is pointing at then points it to the element following the deleted element
		}
		return true;
	}
	else {
		return false;
	}
}

void Battle::removeDead() {
	list<GameCharacter*>::iterator it = vpEnemys.begin();
	while (it != vpEnemys.end()) {
		if ((*it)->isAlive() == false) {
			it = vpEnemys.erase(it);
		}
		else {
			it++;
		}
	}
}

bool Battle::overCheck() {
	bool isOver = true;
	if (vpEnemys.size() == 0) {
		isOver = false;
	}
	return isOver;
}

bool Battle::WonCheck()
{
	return true;
}

void Battle::BattleWon()
{
	system("Clr");
	cout << "#####################################" << endl;
	cout << "You won!" << endl;
	cout << "#####################################" << endl;
	for (GameCharacter* g : this->vpGameCharacters) {
		g->stats();
	}
}
