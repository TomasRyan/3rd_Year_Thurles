#pragma once
#include <list>
#include "GameCharacter.h";
#include "Goblin.h"
#include "Boss.h"
#include "Ogre.h"
#include "Rat.h"
//--------------------------------------------
//	Tom�s Ryan
//	k00243524
// 	take home assignment 2 games programming
//--------------------------------------------
// contains each part of the enemys of the encounter, and allows the building of encounters with reference to the role enum
//--------------------------------------------
class EnemyEncounter {
private:
	// contains a reference to each enemy
	list<GameCharacter*> enemyList;
	// for rng 
	Random generater = Random();
	string encounterName;
public:
	// default constructer
	EnemyEncounter();
	// overloaded cinstructer with a list of enemy references passed in, these must be the enum enemy numbers or else the method will fail
	EnemyEncounter(list<int> enemys);
	// gets the list for referencing from battle.h
	list<GameCharacter*> getEnemyList();
};