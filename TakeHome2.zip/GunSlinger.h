#pragma once
#pragma once
#include "GameCharacter.h";
//--------------------------------------------
//	Tom�s Ryan
//	k00243524
// 	take home assignment 2 games programming
//--------------------------------------------
// gunslinger player type, based off of GameCharecter
//--------------------------------------------
class GunSlinger : public GameCharacter {
private:
	bool bulletDanceReady = false;
public:
	GunSlinger(string name, int h, int s, int a, int d, int l);
	GunSlinger(int x, int y);
	void attack(GameCharacter* target);
	void attack(list<GameCharacter*> targets);
	virtual void Special();
	virtual void stats() const;
	string getName();
	bool specialReady();
	// virtual, so no definition within GameCharacter, check player and enemy for definition
};