#include <stdio.h> 
#include <stdlib.h> 
#include <time.h> 
#include "Random.h"

int Random::getRandom(int floor, int roof)
{
	if (roof > floor) {
		srand(time(NULL));
		int i = rand();
		srand(i);
		i = (rand() % roof) + floor;
		return i;
	}
	else {
		return 0;
	}
}

void Random::randomize() {
	srand(time(NULL));
}
