
#include "Battle.h"
#include "StoryTeller.h"
#include "Creator.h"
#include "Party.h"
//--------------------------------------------
//	Tomás Ryan
//	k002435241
// 	take home assignment 2 games programming
//--------------------------------------------
// main function
//--------------------------------------------
int main() {
	system("Cls");
	Creator create = Creator();
	list<Chapter> c = create.create();
	Party p = Party();
	p.AddPartyMembers();
	StoryTeller story(c, p);
	while (story.storyFinishedCheck() == false) {
		cout << "-----------------------------------" << endl;
		story.printCurrentChapter();
		cout << "-----------------------------------" << endl;
		story.getResponse(); 
		cout << "-----------------------------------" << endl;
		if (p.isPartyAlive() == false) {
			story.gameOver();
		}
		system("Pause");
	}
	story.printCurrentChapter();
	system("Pause");
}