#include "Boss.h";
Boss::Boss(int health) {
	this->m_typeID = boss;
	this->m_maxHealth = health;
	this->m_currHealth = health;
}

Boss::Boss() {
	this->m_name = "The priestress";
	this->m_typeID = boss;
	this->m_maxHealth = 100;
	this->m_currHealth = 100;
	this->m_attack = 8;
	this->m_defense = 4;
	this->m_luck = 10;
	this->m_speed = 3;
}