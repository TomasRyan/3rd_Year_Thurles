#pragma once
class Random {
public:
	int getRandom(int floor, int roof);
	void randomize();
};