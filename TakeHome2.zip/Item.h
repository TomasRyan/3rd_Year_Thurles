#pragma once
class Item{
private:
	enum type {
		Attack,
		Defense,
		Health,
		potion, 
		other
	};
	int m_type;
	int m_class;
	int m_buff;
public:
	Item(int t, int c, int b);


};