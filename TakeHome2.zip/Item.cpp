#include "Item.h"

Item::Item(int t, int c, int b)
{
	this->m_type = t;
	this->m_class = c;
	this->m_buff = b;
}
