#include "Ogre.h";
Ogre::Ogre(int health) {
	this->m_typeID = ogre;
	this->m_maxHealth = health;
	this->m_currHealth = health;
}

Ogre::Ogre() {
	this->m_name = "Ogre";
	this->m_typeID = ogre;
	this->m_maxHealth = 100;
	this->m_currHealth = 100;
	this->m_attack = 5;
	this->m_defense = 2;
	this->m_luck = 15;
	this->m_speed = 3;
}
