#pragma once
#include "GameCharacter.h";
class Rat : public GameCharacter {
private:

public:
	Rat();
	Rat(int health);
};