#include "GunSlinger.h";
GunSlinger::GunSlinger(int x, int y) {
	this->m_xPos = x;
	this->m_yPos = y;
	this->m_typeID = cleric;
}
GunSlinger::GunSlinger(string name, int h, int s, int a, int d, int l) {
	this->m_name = name;
	this->m_maxHealth = h;
	this->m_currHealth = h;
	this->m_speed = s;
	this->m_attack = a;
	this->m_defense = d;
	this->m_luck = l;
	this->attackRange = 6;
}

void GunSlinger::attack(GameCharacter* target) {
	int random = r.getRandom(1, this->m_attack);
	int totalDamage = random;
	while (random == this->m_attack) {
		cout << "|||||||||||||||||||||||||" << endl;
		cout << "|||||||||OVERLOAD||||||||" << endl;
		cout << "|||||||||||||||||||||||||" << endl;
		random = r.getRandom(0, this->m_attack);
		totalDamage += random;
	}
	random = r.getRandom(0, 100);
	if (random < m_luck) {
		totalDamage *= 2;
	}
	if (totalDamage > 0) {
		cout << "#####################################" << endl;
		cout << this->m_name << " attacks " << target->getName() << " for " << totalDamage << " damage!" << endl;
		cout << "#####################################" << endl;
		target->takeDamage(totalDamage);
	}
	else {
		cout << this->m_name << " missed there attack!" << endl;
	}
}

void GunSlinger::attack(list<GameCharacter*> targets) {
	for (GameCharacter* t : targets) {
		t->takeDamage(this->m_attack);
	}
	this->isSpecialReady = false;
}

void GunSlinger::Special() {
	this->isSpecialReady = true;
}

void GunSlinger::stats() const {
	cout << this->m_name << " the GunSlinger" << endl;
	cout << "----------------------------------" << endl;
	cout << "Level: " << this->m_level << endl;
	cout << "Health: " << this->m_currHealth << "/" << this->m_maxHealth << endl;
	cout << "Attack: " << this->m_attack << endl;
	cout << "Defense: " << this->m_defense << endl;
	cout << "Speed: " << this->m_speed << endl;
	cout << "Luck: " << this->m_luck << endl;
}

string GunSlinger::getName()
{
	string temp = this->m_name + " the GunSlinger";
	return  temp;
}
