#include "Chapter.h"

Chapter::Chapter(int ID, string t, list<string> re, list<int> next, list<string> aRe) {
	this->chapterID = ID;
	this->text = t;
	this->responses = re;
	this->nextChapters = next;
	this->availableresponses = aRe;
}

Chapter::Chapter(int ID, string t, list<int> e, int next) {
	this->chapterID = ID;
	this->text = t;
	this->nextChapters.push_back(next);
	this->listOfEnemys = EnemyEncounter(e);
	this->fight = true;
}

void Chapter::printText(Party p) {
	cout << this->text << endl;
	if (this->fight == false) {
		
		cout << "What would you like to do?" << endl;
		cout << "----------------------------------------" << endl;
		int count = 1;
		for (string i : this->availableresponses) {
			cout << count << ": " << i << endl;
			count++;
		}
	}
}

int Chapter::printResponse(Party p, string index) {
	if (this->fight == false) {
		int inputsID = input.numberChecker(index);
		int counter = 0;
		if (inputsID == NULL) {
			inputsID = 0;
		}
		for (string i : this->responses) {
			if (counter == inputsID) {
				cout << i << endl;
				int nextCounter = 0;
				for (int y : this->nextChapters) {
					if (nextCounter == inputsID) {
						return y;
					}
					nextCounter++;
				}
			}
			counter++;
		}
	}
	else {

		Battle b(p, this->listOfEnemys);
		b.battleLoop();
		for (GameCharacter* part : p.getPartyList()) {
			part->levelUp();
		}
		//b.BattleWin();
		int temp = this->nextChapters.front();
		return temp;
	}
	return this->chapterID; // repeat current chapter if needed
}



bool Chapter::victorCheck()
{
	if (this->chapterFight.WonCheck()) {
		return true;
	}
	else {
		return false;
	}
}

bool Chapter::fightChecker()
{
	return this->fight;
}

void Chapter::fightScene(Party p) {
	this->chapterFight = Battle(p, this->listOfEnemys);
}

