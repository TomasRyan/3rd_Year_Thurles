//--------------------------------------------
//	Tom�s Ryan
//	k00243524
// 	take home assignment 2 games programming
//--------------------------------------------
// storryteller runs the flow of the game, containing each chapter and how they connect to each other
//--------------------------------------------

#include "Chapter.h"
#include "Party.h"
class StoryTeller {
private:
	// 
	//	everything will be printed to this list to keep a record if player wants to keep track
	Party party;
	list<string> recordKeeper;
	list<int> criticalPath;
	//	the current screen on the story
	int currentSection = 0;
	//
	list<Chapter> ChapterList;
	bool inFight = false;
	bool storyIsOver = false;
public:
	StoryTeller();
	// gets a pointed list off ALL chapters in the game
	StoryTeller(list<Chapter> c, Party p);
	// change the chapter the player is on
	void goToSection(int p);
	//	prints the chapter main text of the index entered
	void printSection(int index);
	//	prints the current chapter that the index is stored within ChapterList
	void printCurrentChapter();
	//	get the response for the cvurrent chapter
	void getResponse();
	// start a fight, returns if the fight was won if true
	bool startAFight(list<int> e);
	//	check if we in a fight
	bool fightCheck();
	// checks if the story is over yet or not
	bool storyFinishedCheck();
	// game over text, and exits the game
	void gameOver();
};