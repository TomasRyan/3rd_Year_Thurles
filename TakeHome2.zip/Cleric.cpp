#include "Cleric.h";
Cleric::Cleric(int x, int y) {
	this->m_xPos = x;
	this->m_yPos = y;
	this->m_typeID = cleric;
}
Cleric::Cleric(string name, int h, int s, int a, int d, int l) {
	this->m_name = name;
	this->m_maxHealth = h;
	this->m_currHealth = h;
	this->m_speed = s;
	this->m_attack = a;
	this->m_defense = d;
	this->m_luck = l;
	this->m_typeID = cleric;
}


//void Cleric::attack(GameCharacter* target) {
//	target->takeDamage(this->m_attack);
//}

void Cleric::Special(list<GameCharacter*> party) {
	cout << this->getName() << " Heals the party" << endl;
	for (GameCharacter* c : party) {
		c->healingUnit(this->healAmount);
	}
}

void Cleric::stats() const {
	cout << this->m_name << " the Cleric" << endl;
	cout << "----------------------------------" << endl;
	cout << "Level: " << this->m_level << endl;
	cout << "Health: " << this->m_currHealth << "/" << this->m_maxHealth << endl;
	cout << "Attack: " << this->m_attack << endl;
	cout << "Defense: " << this->m_defense << endl;
	cout << "Speed: " << this->m_speed << endl;
	cout << "Luck: " << this->m_luck << endl;
}

string Cleric::getName()
{
	string temp = this->m_name + " the Cleric";
	return  temp;
}

