#include "StoryTeller.h"
StoryTeller::StoryTeller() {

}

StoryTeller::StoryTeller(list<Chapter> c, Party p) {
	this->ChapterList.assign(c.begin(), c.end());
	this->party = p;
}
// change the chapter the player is on
void StoryTeller::goToSection(int p) {
	this->criticalPath.push_back(this->currentSection);
	this->currentSection = p;
}

void StoryTeller::printSection(int index) {
	int counter = 0;
	for (Chapter c : this->ChapterList) {
		if (counter == index) {
			if (c.fightChecker()) {
				c.fightScene(this->party);
			}
			(c).printText(this->party);
		}
		counter++;
	}
}


void StoryTeller::printCurrentChapter() {
	int counter = 0;
	for (Chapter c : this->ChapterList) {
		if (counter == this->currentSection) {
			c.printText(this->party);
		}
		counter++;
	}
}
// check each branch to see if it continues
void StoryTeller::getResponse() {
	int counter = 0;
	string temp = "";
	cin >> temp;
	cin.clear();
	cout << "----------------------------------------" << endl;
	for (Chapter c : this->ChapterList) {
		if (counter == this->currentSection) {
			int nextScene = c.printResponse(this->party, temp);
			goToSection(nextScene);
			break;
		}
		counter++;
	}
}

bool StoryTeller::fightCheck()
{
	return this->inFight;
}

bool StoryTeller::storyFinishedCheck() {
	if (this->currentSection == 16) {
		this->storyIsOver = true;
	}
	return this->storyIsOver;
}


void StoryTeller::gameOver() {
	cout << "You have failed your quest" << endl;
	cout << "Game Over" << endl;
	system("Pause");
	exit(0);
}

bool StoryTeller::startAFight(list<int> e) {
	return true;
}
