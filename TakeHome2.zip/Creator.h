#include "Chapter.h"
#include "Random.h"
//--------------------------------------------
//	Tom�s Ryan
//	k00243524
// 	take home assignment 2 games programming
//--------------------------------------------
// contains methods for simly creating the list of chapters, as seen within Creator.cpp
//--------------------------------------------
class Creator {
private:
	Random r = Random();
public:
	list<Chapter> create();
};