#pragma once
#pragma once
#include "GameCharacter.h";
//--------------------------------------------
//	Tom�s Ryan
//	k00243524
// 	take home assignment 2 games programming
//--------------------------------------------
// Boss enemy type, based off of GameCharecter
//--------------------------------------------
class Boss : public GameCharacter {
private:

public:
	Boss();
	Boss(int health);
};